
<!DOCTYPE HTML>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="author" content="colorlib.com">
	<title>SunUp International School & College Certificate Verification</title>
	<link href="../certificate_verification/images/Sunup_Logo.png" rel="shortcut icon" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500" rel="stylesheet" />
    <link href="css/maincss.php" rel="stylesheet" />
  </head>
  <body>
	
    <div class="s002">
	
      <form class="s0030" action="/sunup/certificate_verification/index.php" method="POST">
	  
		<fieldset>
          <legend><img class="s00440" src="../certificate_verification/images/Sunup_Logo.png" alt="" height="160" width="200"></legend>
        </fieldset>
	  
	  
        <fieldset>
          <legend><div class="s00550"><b>Certificate Verification</b></div></legend>
        </fieldset>
	  
		
        <div class="inner-form">
		
          <div class="input-field first-wrap">
            <div class="icon-wrap">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                <path d="M18.303,4.742l-1.454-1.455c-0.171-0.171-0.475-0.171-0.646,0l-3.061,3.064H2.019c-0.251,0-0.457,0.205-0.457,0.456v9.578c0,0.251,0.206,0.456,0.457,0.456h13.683c0.252,0,0.457-0.205,0.457-0.456V7.533l2.144-2.146C18.481,5.208,18.483,4.917,18.303,4.742 M15.258,15.929H2.476V7.263h9.754L9.695,9.792c-0.057,0.057-0.101,0.13-0.119,0.212L9.18,11.36h-3.98c-0.251,0-0.457,0.205-0.457,0.456c0,0.253,0.205,0.456,0.457,0.456h4.336c0.023,0,0.899,0.02,1.498-0.127c0.312-0.077,0.55-0.137,0.55-0.137c0.08-0.018,0.155-0.059,0.212-0.118l3.463-3.443V15.929z M11.241,11.156l-1.078,0.267l0.267-1.076l6.097-6.091l0.808,0.808L11.241,11.156z"></path>
              </svg>
            </div>
            <input type="text" id="search" name="tc_no" placeholder="REF. NO" required>
          </div>
		  
		  <div class="input-field first-wrap">
            <div class="icon-wrap">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                <path d="M18.303,4.742l-1.454-1.455c-0.171-0.171-0.475-0.171-0.646,0l-3.061,3.064H2.019c-0.251,0-0.457,0.205-0.457,0.456v9.578c0,0.251,0.206,0.456,0.457,0.456h13.683c0.252,0,0.457-0.205,0.457-0.456V7.533l2.144-2.146C18.481,5.208,18.483,4.917,18.303,4.742 M15.258,15.929H2.476V7.263h9.754L9.695,9.792c-0.057,0.057-0.101,0.13-0.119,0.212L9.18,11.36h-3.98c-0.251,0-0.457,0.205-0.457,0.456c0,0.253,0.205,0.456,0.457,0.456h4.336c0.023,0,0.899,0.02,1.498-0.127c0.312-0.077,0.55-0.137,0.55-0.137c0.08-0.018,0.155-0.059,0.212-0.118l3.463-3.443V15.929z M11.241,11.156l-1.078,0.267l0.267-1.076l6.097-6.091l0.808,0.808L11.241,11.156z"></path>
              </svg>
            </div>
            <input type="text" id="search" name="student_id" placeholder="REG. NO" required>
          </div>
		  
		  <div class="input-field fouth-wrap">
            <div class="icon-wrap">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                <path d="M9.896,3.838L0.792,1.562v14.794l9.104,2.276L19,16.356V1.562L9.896,3.838z M9.327,17.332L1.93,15.219V3.27
				l7.397,1.585V17.332z M17.862,15.219l-7.397,2.113V4.855l7.397-1.585V15.219z"></path>
			
              </svg>
            </div>
			
						
            <select data-trigger="" name="class_id">
				<option placeholder="">Class</option>
				<option value=1 >Play - English Version</option><option value=2 >Play - Bangla Version</option><option value=3 >Nursery - English Version</option><option value=4 >Nursery - Bangla Version</option><option value=5 >K.G - English Version</option><option value=6 >K.G - Bangla Medium</option><option value=7 >One - English Version</option><option value=8 >One - Bangla Medium</option><option value=9 >Two - English Version</option><option value=10 >Two - Bangla Medium</option><option value=11 >Three - English Version</option><option value=12 >Three - Bangla Medium</option><option value=13 >Four - English Version</option><option value=14 >Four - Bangla Medium</option><option value=15 >Five - English Version</option><option value=16 >Five - Bangla Medium</option><option value=17 >Six - English Version</option><option value=18 >Six - Bangla Medium</option><option value=19 >Seven - English Version</option><option value=20 >Seven - Bangla Medium</option><option value=21 >Eight - English Version</option><option value=22 >Eight - Bangla Medium</option><option value=23 >Nine - English Version</option><option value=24 >Nine - Bangla Medium</option><option value=25 >Ten - English Version</option><option value=26 >Ten - Bangla Medium</option><option value=27 >SSC - English Version</option><option value=28 >SSC - Bangla Medium</option><option value=29 >Eleven - English Version</option><option value=30 >Eleven - Bangla Medium</option><option value=31 >Twelve - English Version</option><option value=32 >Twelve - Bangla Medium</option><option value=33 >HSC - English Version</option><option value=34 >HSC - Bangla Medium</option>				
				            </select>
          </div>
		 
          <div class="input-field second-wrap">
            <div class="icon-wrap">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                <path d="M17 12h-5v5h5v-5zM16 1v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2h-1V1h-2zm3 18H5V8h14v11z"></path>
              </svg>
            </div>
            <input class="datepicker" type="text" id="depart" name="dob" placeholder="Brith Date" />
          </div>
		  
          <div class="input-field fifth-wrap">
            <!--<button class="btn-search" type="button" name="Submit">SEARCH</button>-->
			<input class="btn-search" type="Submit" name="searchs" value="SEARCH">
          </div>
		  
        </div>
		
		<br><br>
						
      </form>
	  
    </div>
    <script src="js/extention/choices.js"></script>
    <script src="js/extention/flatpickr.js"></script>
    <script>
      flatpickr(".datepicker",
      {});

    </script>
    <script>
      const choices = new Choices('[data-trigger]',
      {
        searchEnabled: false,
        //itemSelectText: '',
      });

    </script>
  </body><!-- This Designed & Developed by (https://freedomsoftbd.com/)-->
</html>
